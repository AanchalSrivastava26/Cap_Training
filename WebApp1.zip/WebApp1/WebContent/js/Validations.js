function validateRegistrationForm(){
	if(registrationForm.firstName.value==""){
		alert("enter first name");
		return false;
	}
	else if(registrationForm.lastName.value==""){
		alert("enter last name");
		return false;
	}
	else if(registrationForm.emailId.value==""){
		alert("enter email id");
		return false;
	}
	else if(registrationForm.department.value==""){
		alert("enter department");
		return false;
	}
	else if(registrationForm.designation.value==""){
		alert("enter designation");
		return false;
	}
	else if(registrationForm.panCard.value==""){
		alert("enter pan card number");
		return false;
	}
	else if(registrationForm.yearlyInvestmentUnder80C.value==""){
		alert("enter yearly investment under 80 c");
		return false;
	}
	else if(registrationForm.basicSalary.value==""){
		alert("enter basic salary");
		return false;
	}
	else if(registrationForm.bankName.value==""){
		alert("enter bank name");
		return false;
	}
	else if(registrationForm.ifscCode.value==""){
		alert("enter ifsc code");
		return false;
	}
	else
		return true;
}