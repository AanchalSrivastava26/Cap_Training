package com.cg.project.servlets;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.catalina.connector.Request;

import com.cg.project.bean.UserBean;

@WebServlet("/register1")
public class RegistrationServlet2 extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		PrintWriter out=response.getWriter();
		int associateId=Integer.parseInt(request.getParameter("associateId"));
		String firstName=request.getParameter("firstName");
		String password=request.getParameter("password");
		String lastName=request.getParameter("lastName");
		String emailId=request.getParameter("emailId");
		String mobileNo=request.getParameter("mobileNo");
		String gender=request.getParameter("gender");
		String[] communication=request.getParameterValues("communication");
		List<String> communicationList=new ArrayList<>(Arrays.asList(communication));
		UserBean bean=new UserBean(password, firstName, lastName, emailId, mobileNo, gender, communicationList);
		RequestDispatcher dispatcher=request.getRequestDispatcher("RegistrationDetailsPage.jsp");
		request.setAttribute("bean", bean);
		dispatcher.forward(request, response);
	}
}
