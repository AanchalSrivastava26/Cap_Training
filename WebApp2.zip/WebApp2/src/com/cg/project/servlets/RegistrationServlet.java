package com.cg.project.servlets;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/register")
public class RegistrationServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
    
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		PrintWriter out=response.getWriter();
		String firstName=request.getParameter("firstName");
		String lastName=request.getParameter("lastName");
		String emailId=request.getParameter("emailId");
		String department=request.getParameter("department");
		String designation=request.getParameter("designation");
		String panCard=request.getParameter("panCard");
		int yearlyInvestmentUnder80C=Integer.parseInt(request.getParameter("yearlyInvestmentUnder80C"));
		int basicSalary=Integer.parseInt(request.getParameter("basicSalary"));
		int accountNo=Integer.parseInt(request.getParameter("accountNo"));
		String bankName=request.getParameter("bankName");
		String ifscCode=request.getParameter("ifscCode");
		out.println("<html><body>");
		out.println("<div>");
		out.println("firstName :"+firstName+"<br>lastName :"+lastName+"<br>email Id :"+emailId+"<br>deoartment :"+department
				+"<br>designation :"+designation+"<br>panCard :"+panCard+"<br>investment:"+yearlyInvestmentUnder80C
				+"<br>basic Salary :"+basicSalary+"<br>account number :"+accountNo+"<br>bank name :"+bankName
				+"<br>ifsc code :"+ifscCode);
		out.println("</div>");
		out.println("</body></html>");
		
	}

}
