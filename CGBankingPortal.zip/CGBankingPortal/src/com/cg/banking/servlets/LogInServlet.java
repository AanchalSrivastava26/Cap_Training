package com.cg.banking.servlets;

import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cg.banking.beans.Account;


@WebServlet("/logIn")
public class LogInServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
 protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
long accountNo=Long.parseLong(request.getParameter("accountNo"));
	int  pinNumber=Integer.parseInt(request.getParameter("pinNumber"));
			Account account=new Account(accountNo, pinNumber);
	RequestDispatcher dispatcher=null;
if(account.getAccountNo()==111 && account.getPinNumber()==3452)
{
	dispatcher=request.getRequestDispatcher("LogInSuccessPage.jsp");
request.setAttribute("account", account);
dispatcher.forward(request, response);
 }
 else {
	 dispatcher=request.getRequestDispatcher("LogInErrorPage.jsp");
	 request.setAttribute("error", "user id or password is wrong");
	 dispatcher.forward(request, response);
 }
	 
 }
}
