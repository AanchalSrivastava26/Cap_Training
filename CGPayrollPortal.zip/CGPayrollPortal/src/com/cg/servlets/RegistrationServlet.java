package com.cg.servlets;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cg.payroll.beans.Associate;
import com.cg.payroll.beans.BankDetails;
import com.cg.payroll.beans.Salary;
import com.cg.payroll.services.PayrollServices;
import com.cg.payroll.services.PayrollServicesImpl;

@WebServlet("/register")
public class RegistrationServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		PayrollServices payrollServices=new PayrollServicesImpl();
		String firstName=request.getParameter("firstName");
		String lastName=request.getParameter("lastName");
		String emailId=request.getParameter("emailId");
		String department=request.getParameter("department");
		String designation=request.getParameter("designation");
		String pancard=request.getParameter("pancard");
		String password=request.getParameter("password");
		int epf=Integer.parseInt(request.getParameter("epf"));
		int companyPf=Integer.parseInt(request.getParameter("companyPf"));
		int yearlyInvestmentUnder80C=Integer.parseInt(request.getParameter("yearlyInvestmentUnder80C"));
		int basicSalary=Integer.parseInt(request.getParameter("basicSalary"));
		int accountNo=Integer.parseInt(request.getParameter("accountNo"));
		String bankName=request.getParameter("bankName");
		String ifscCode=request.getParameter("ifscCode");
		Associate associate=new Associate(yearlyInvestmentUnder80C, firstName, lastName,department, designation, pancard, password,emailId, 
				new Salary(basicSalary, epf, companyPf),new  BankDetails(accountNo,bankName, ifscCode));
		RequestDispatcher dispatcher=null;
		payrollServices.acceptAssociateDetails(associate);
		dispatcher=request.getRequestDispatcher("RegistrationSuccessfulPage.jsp");
		request.setAttribute("associate", associate);
		dispatcher.forward(request, response);
	}
}