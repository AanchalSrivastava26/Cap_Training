package com.cg.servlets;

import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import com.cg.payroll.beans.Associate;

@WebServlet("/logIn")
public class LogInServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
 protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
int associateId=Integer.parseInt(request.getParameter("associateId"));
	String password=request.getParameter("password");
	Associate associate=new Associate(associateId,password);
	RequestDispatcher dispatcher=null;
if(associate.getAssociateID()==111 && associate.getPassword().equals("aanchal"))
{
	dispatcher=request.getRequestDispatcher("LogInSuccessPage.jsp");
request.setAttribute("associate", associate);
dispatcher.forward(request, response);
 }
 else {
	 dispatcher=request.getRequestDispatcher("LogInErrorPage.jsp");
	 request.setAttribute("error", "user id or password is wrong");
	 dispatcher.forward(request, response);
 }
	 
 }
}
