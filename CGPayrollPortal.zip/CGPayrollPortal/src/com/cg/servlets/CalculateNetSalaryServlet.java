package com.cg.servlets;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cg.payroll.beans.Associate;
import com.cg.payroll.beans.BankDetails;
import com.cg.payroll.beans.Salary;
import com.cg.payroll.exceptions.AssociateDetailsNotFoundException;
import com.cg.payroll.services.PayrollServices;
import com.cg.payroll.services.PayrollServicesImpl;

@WebServlet("/netSalary")
public class CalculateNetSalaryServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		PayrollServices payrollServices=new PayrollServicesImpl();
		Associate associate=new Associate();
		RequestDispatcher dispatcher=null;
		try {
			payrollServices.calculateNetSalary(associate.getAssociateID());
		} catch (AssociateDetailsNotFoundException e) {

			System.err.println(e);
		}

		dispatcher=request.getRequestDispatcher("CalculateSalarySuccessful.jsp");
		request.setAttribute("associate", associate);
		dispatcher.forward(request, response);

	}

}
