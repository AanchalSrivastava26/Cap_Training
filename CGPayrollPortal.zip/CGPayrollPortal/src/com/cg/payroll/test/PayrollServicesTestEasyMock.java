package com.cg.payroll.test;

import java.util.ArrayList;


import org.easymock.EasyMock;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

import com.cg.payroll.beans.Associate;
import com.cg.payroll.beans.BankDetails;
import com.cg.payroll.beans.Salary;
import com.cg.payroll.daoservices.AssociateDAO;
import com.cg.payroll.exceptions.AssociateDetailsNotFoundException;
import com.cg.payroll.services.PayrollServices;
import com.cg.payroll.services.PayrollServicesImpl;

import org. junit.Assert;

public class PayrollServicesTestEasyMock {
	private static PayrollServices payrollServices;
	private static AssociateDAO mockAssociateDao;
	/*@BeforeClass
	public static void setUpTestEnv() {
		mockAssociateDao=EasyMock.mock(AssociateDAO.class);
		payrollServices=new PayrollServicesImpl(mockAssociateDao);
	}
	@Before
	public void setUpTestMockData() {
		Associate associate1=new Associate(101, 30000, "aanchal", "srivastava", "xyz", "analyst", "jyup1524","aanchal@gmail.com", 
				new Salary(20000, 1200, 2300),new  BankDetails("hdfc", "hdfc215425"));

		Associate associate2=new Associate(102, 40000, "prachi", "srivastava", "abc", "analyst", "jyup1424","prachi@gmail.com", 
				new Salary(10000, 1200, 2300),new  BankDetails("icici", "icici215425"));
		Associate associate3=new Associate( 60000, "abc", "xyz", "dgd", "analyst", "jyup1443","abc@gmail.com", 
				new Salary(10000, 1200, 2300),new  BankDetails("hdfc", "hdfc215425"));
		ArrayList<Associate> associateList=new ArrayList<>();
		associateList.add(associate1);
		associateList.add(associate2);
		EasyMock.expect(mockAssociateDao.save(associate3)).andReturn(associate3);
		EasyMock.expect(mockAssociateDao.findOne(101)).andReturn(associate1);
		EasyMock.expect(mockAssociateDao.findOne(102)).andReturn(associate2);
		EasyMock.expect(mockAssociateDao.findOne(103)).andReturn(associate3);
		EasyMock.expect(mockAssociateDao.findOne(1234)).andReturn(null);
		EasyMock.replay(mockAssociateDao);

	}
	@Test(expected=AssociateDetailsNotFoundException.class)
	public void testGetAssociateDataForInvalidAssociateId( )throws AssociateDetailsNotFoundException{
		payrollServices.getAssociateDetails(1234);
		EasyMock.verify(mockAssociateDao.findOne(1234));
	}

	@Test
	public void testGetAssociateDataForValidAssociateId() throws AssociateDetailsNotFoundException{
		Associate expectedAssociate=new Associate(101, 30000, "aanchal", "srivastava", "xyz", "analyst", "jyup1524","aanchal@gmail.com", 
				new Salary(20000, 1200, 2300),new  BankDetails("hdfc", "hdfc215425"));
		Associate actualAssociate=payrollServices.getAssociateDetails(101);
		Assert.assertEquals(expectedAssociate,actualAssociate);
		EasyMock.verify(mockAssociateDao.findOne(101));
	}


	@Test(expected=AssociateDetailsNotFoundException.class)
	public void testCalculateNetSalaryForInvalidAssociateId() throws AssociateDetailsNotFoundException{
		payrollServices.getAssociateDetails(1234);
		EasyMock.verify(mockAssociateDao.findOne(1234));
	}
	@Test
	public  void testCalculateNetSalaryForValidAssociateId() throws AssociateDetailsNotFoundException {
		int expectedSalary=630000;
		int actualNetSalary=payrollServices.calculateNetSalary(101);
		EasyMock.verify(mockAssociateDao.findOne(101));
		Assert.assertEquals(expectedSalary,actualNetSalary);
	}
	@Test
	public void testForGetAllAssociateDetails() {
		ArrayList<Associate>actualAssociateList=(ArrayList<Associate>)payrollServices.getAllAssociatesDetails();
		EasyMock.verify(mockAssociateDao.findAll());
		
	}
	@After
	public void tearDownTestData() {
		EasyMock.resetToDefault(mockAssociateDao);

	}
	@AfterClass
	public static void tearDownTestEnv() {
		mockAssociateDao=null;
		payrollServices=null;
	}
*/
}
