function validateLogInForm(){
	if(logInForm.firstName.value==""){
		alert("enter first name");
		return false;
	}
	else if(logInForm.lastName.value==""){
		alert("enter last name");
		return false;
	}
	else if(logInForm.emailId.value==""){
		alert("enter email id");
		return false;
	}
	else if(logInForm.department.value==""){
		alert("enter department");
		return false;
	}
	else if(logInForm.designation.value==""){
		alert("enter designation");
		return false;
	}
	else if(logInForm.panCard.value==""){
		alert("enter pan card number");
		return false;
	}
	else if(logInForm.yearlyInvestmentUnder80C.value==""){
		alert("enter yearly investment under 80 c");
		return false;
	}
	else if(logInForm.basicSalary.value==""){
		alert("enter basic salary");
		return false;
	}
	else if(logInForm.bankName.value==""){
		alert("enter bank name");
		return false;
	}
	else if(logInForm.ifscCode.value==""){
		alert("enter ifsc code");
		return false;
	}
	else
		return true;
}