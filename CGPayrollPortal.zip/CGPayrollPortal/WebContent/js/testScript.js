for (var a = 0; a < 11; a++) {
	document.write("aanchal <br/>");
	console.log("console output");
}

function addNumbers(){
	var n1=parseInt(document.mathFrm.num1.value);
	var n2=parseInt(document.mathFrm.num2.value);
	var n3=n1+n2;
	document.mathFrm.ans.value=n3;
}
function callForWork(){
	alert("alert box message");
	document.write("good morning");
}